## Mini Tasks

-   close icon/animation
-   icons
-   style popup
-   right click menu
-   other styles from shadowfox
